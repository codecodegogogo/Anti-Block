# AdClose anti-fraud extract

This folder keeps only the anti-fraud block from `GGAT_10007`.

Contents:

- `rules/anti_fraud_hosts.txt`: host rules copied from the anti-fraud section of `Host/all`.
- `rules/anti_fraud_ips.txt`: IP drop rules copied from the anti-fraud section of `mod/iptables.sh`.
- `rules/anti_fraud_packages.txt`: package network redirects from `mod/iptables.sh`.
- `system/etc/hosts`: a minimal hosts file using only the anti-fraud host rules.
- `service.sh`: runs `anti_fraud_iptables.sh` after boot.
- `adguardhome/anti_fraud_dns_filter.txt`: AdGuard Home-compatible DNS rules
  generated from the anti-fraud host rules.

For an existing AdClose module, merge `rules/anti_fraud_hosts.txt` into its hosts list and call:

```sh
sh "$MODDIR/anti_fraud_iptables.sh"
```

from that module's `service.sh`.

For AdGuard Home, use `adguardhome/anti_fraud_dns_filter.txt`. The IP list in
`rules/anti_fraud_ips.txt` still requires a firewall; AdGuard Home cannot block
direct IP connections by DNS filtering alone.
