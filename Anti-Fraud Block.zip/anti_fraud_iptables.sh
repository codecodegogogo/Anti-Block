#!/system/bin/sh
MODDIR=${0%/*}
RULEDIR="$MODDIR/rules"
IPTABLES="${IPTABLES:-iptables}"

PACKAGES_FILE="$RULEDIR/anti_fraud_packages.txt"
IPS_FILE="$RULEDIR/anti_fraud_ips.txt"
HOSTS_FILE="$RULEDIR/anti_fraud_hosts.txt"

command -v "$IPTABLES" >/dev/null 2>&1 || exit 0

apply_package_redirects() {
  [ -r "$PACKAGES_FILE" ] || return 0
  [ -r /data/system/packages.list ] || return 0

  while IFS= read -r package || [ -n "$package" ]; do
    case "$package" in
      ""|\#*) continue ;;
    esac

    uid=$(awk -v package="$package" '$1 == package { print $2; exit }' /data/system/packages.list)
    [ -n "$uid" ] || continue

    while "$IPTABLES" -t nat -D OUTPUT -m owner --uid-owner "$uid" -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1; do
      :
    done
    "$IPTABLES" -t nat -I OUTPUT -m owner --uid-owner "$uid" -p tcp -d 0.0.0.0/0 -j DNAT --to-destination 127.0.0.1:8848 >/dev/null 2>&1
  done < "$PACKAGES_FILE"
}

apply_ip_drops() {
  [ -r "$IPS_FILE" ] || return 0

  while IFS= read -r target || [ -n "$target" ]; do
    case "$target" in
      ""|\#*) continue ;;
    esac

    while "$IPTABLES" -D OUTPUT -d "$target" -j DROP >/dev/null 2>&1; do
      :
    done
    "$IPTABLES" -A OUTPUT -d "$target" -j DROP >/dev/null 2>&1
  done < "$IPS_FILE"
}

apply_domain_string_drops() {
  [ -r "$HOSTS_FILE" ] || return 0

  awk '$1 == "0.0.0.0" && $2 != "" { print $2 }' "$HOSTS_FILE" | while IFS= read -r domain; do
    [ -n "$domain" ] || continue

    while "$IPTABLES" -D OUTPUT -m string --string "$domain" --algo bm --to 65535 -j DROP >/dev/null 2>&1; do
      :
    done
    "$IPTABLES" -A OUTPUT -m string --string "$domain" --algo bm --to 65535 -j DROP >/dev/null 2>&1
  done
}

apply_package_redirects
apply_ip_drops
apply_domain_string_drops
