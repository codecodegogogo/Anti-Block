#!/system/bin/sh
MODDIR=${0%/*}

export PATH=/system/bin:/system/xbin:$PATH

(
  sleep 20
  sh "$MODDIR/anti_fraud_iptables.sh"
  sleep 60
  sh "$MODDIR/anti_fraud_iptables.sh"
) >/dev/null 2>&1 &
